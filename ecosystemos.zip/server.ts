import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API Routes
app.post("/api/match/mentors", async (req, res) => {
  try {
    const { startup, mentors } = req.body;
    
    const prompt = `
      You are EcosystemOS AI. Match the following startup with available mentors.
      
      Startup: ${JSON.stringify(startup)}
      Mentors: ${JSON.stringify(mentors)}
      
      Return a ranked list of top 3 mentors with:
      - Rank
      - Mentor Name
      - Score (0-100)
      - Reason (1 sentence)
      - Confidence (High/Medium/Low)
      
      Return as JSON array: [{rank, name, score, reason, confidence}]
    `;

    const result = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    
    const responseText = result.text;
    if (!responseText) {
      throw new Error("Empty response from AI");
    }
    
    const jsonMatch = responseText.match(/\[.*\]/s);
    if (jsonMatch) {
      res.json(JSON.parse(jsonMatch[0]));
    } else {
      res.status(500).json({ error: "Failed to parse AI response" });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Verification check
app.post("/api/verify/startup", async (req, res) => {
   try {
    const { profile } = req.body;

    const prompt = `
      Analyze this startup registration and generate a verification checklist.
      Profile: ${JSON.stringify(profile)}
      
      Return:
      - trustScore (0-100)
      - missingItems (array of strings)
      - recommendation (string)
      
      Return as JSON: {trustScore, missingItems, recommendation}
    `;

    const result = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    const responseText = result.text;
    if (!responseText) {
      throw new Error("Empty response from AI");
    }

    const jsonMatch = responseText.match(/\{.*\}/s);
    if (jsonMatch) {
      res.json(JSON.parse(jsonMatch[0]));
    } else {
      res.status(500).json({ error: "Failed to parse AI response" });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
