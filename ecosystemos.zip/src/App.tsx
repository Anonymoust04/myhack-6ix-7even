import { useState, useEffect } from 'react';
import { auth, db, handleFirestoreError, OperationType } from './lib/firebase';
import { 
  GoogleAuthProvider, 
  signInWithPopup, 
  onAuthStateChanged,
  User,
  signOut
} from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  getDocs,
  addDoc,
  Timestamp 
} from 'firebase/firestore';
import { 
  LayoutDashboard, 
  Users, 
  Briefcase, 
  Link as LinkIcon, 
  LogOut, 
  Plus,
  Search,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Globe,
  Loader2,
  ShieldCheck,
  Star,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import AddEntityModal from './components/AddEntityModal';

// --- Types ---
interface Startup {
  id: string;
  name: string;
  industry: string;
  stage: string;
  geography: string;
  isVerified: boolean;
  trustScore: number;
}

interface Mentor {
  id: string;
  name: string;
  expertise: string[];
  geography: string;
  rating: number;
}

interface Relationship {
  id: string;
  type: string;
  status: string;
  matchScore: number;
  tags: string[];
  createdAt: any;
  companyName?: string;
  mentorName?: string;
}

// --- Components ---

const Sidebar = ({ activeTab, setActiveTab, user, relationships }: { activeTab: string, setActiveTab: (t: string) => void, user: User | null, relationships: Relationship[] }) => {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'startups', label: 'Startups', icon: Briefcase },
    { id: 'mentors', label: 'Mentors', icon: Users },
    { id: 'relationships', label: 'Relationship Engine', icon: LinkIcon },
    { id: 'verification', label: 'Verification', icon: ShieldCheck },
  ];

  return (
    <aside className="w-64 bg-slate-900 flex flex-col flex-shrink-0 h-screen fixed left-0 top-0 overflow-hidden">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">OS</div>
          <span className="text-xl font-bold tracking-tight text-white">EcosystemOS</span>
        </div>
        <nav className="space-y-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === tab.id 
                  ? 'bg-slate-800 text-white' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <tab.icon className={`w-4 h-4 ${activeTab === tab.id ? 'text-blue-400' : 'text-slate-500'}`} />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6 bg-slate-950/50">
        <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-3 font-bold">Ecosystem Health</div>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs text-slate-300 mb-1 font-medium">
              <span>Active Links</span>
              <span className="font-mono text-blue-400">{relationships.length}</span>
            </div>
            <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
              <div className="bg-blue-400 h-full w-[82%]"></div>
            </div>
          </div>
          <div className="flex items-center gap-3 mt-4 pt-4 border-t border-slate-800/50">
            <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 text-xs font-bold font-mono">
              {user?.displayName?.charAt(0) || 'U'}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-[11px] font-bold text-slate-200 truncate leading-none mb-1">{user?.displayName}</p>
              <button 
                onClick={() => signOut(auth)}
                className="text-[10px] text-slate-500 hover:text-red-400 transition-colors uppercase font-bold tracking-tighter"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

const MetricCard = ({ label, value, trend, icon: Icon, variant = 'neutral' }: any) => {
  const variants = {
    neutral: 'bg-slate-50 rounded-xl',
    success: 'bg-emerald-50 border border-emerald-100 text-emerald-900',
    brand: 'bg-blue-50 border border-blue-100 text-blue-900'
  };

  return (
    <div className={`p-4 ${variants[variant as keyof typeof variants] || variants.neutral}`}>
      <div className="text-2xl font-bold tracking-tight mb-1">{value}</div>
      <div className="text-[10px] text-slate-500 uppercase tracking-wide font-bold">{label}</div>
      {trend && (
        <span className="text-[10px] font-bold text-emerald-600 mt-1 block">
          {trend}
        </span>
      )}
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [region, setRegion] = useState('SE Asia / Kuala Lumpur');
  const [startups, setStartups] = useState<Startup[]>([]);
  const [mentors, setMentors] = useState<Mentor[]>([]);
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'startup' | 'mentor'>('startup');
  const [matchSuggestions, setMatchSuggestions] = useState<any[]>([]);
  const [isMatching, setIsMatching] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) {
        fetchData();
      }
    });
    return unsubscribe;
  }, []);

  const fetchData = async () => {
    try {
      const qStartups = query(collection(db, 'companies'));
      const snapshotStartups = await getDocs(qStartups);
      setStartups(snapshotStartups.docs.map(doc => ({ id: doc.id, ...doc.data() } as Startup)));

      const qMentors = query(collection(db, 'mentors'));
      const snapshotMentors = await getDocs(qMentors);
      setMentors(snapshotMentors.docs.map(doc => ({ id: doc.id, ...doc.data() } as Mentor)));

      const qRels = query(collection(db, 'relationships'));
      const snapshotRels = await getDocs(qRels);
      setRelationships(snapshotRels.docs.map(doc => ({ id: doc.id, ...doc.data() } as Relationship)));
    } catch (err) {
      console.error(err);
    }
  };

  const signIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error(err);
    }
  };

  const seedData = async () => {
    if (!auth.currentUser) return;
    setLoading(true);
    try {
      // Seed startups
      const startupsToSeed = [
        { name: "GreenTrace", industry: "AgriTech", stage: "scale", geography: "Kuala Lumpur", isVerified: true, trustScore: 92 },
        { name: "PayShield", industry: "FinTech", stage: "MVP", geography: "Singapore", isVerified: false, trustScore: 45 }
      ];
      for (const s of startupsToSeed) {
        await addDoc(collection(db, 'companies'), { ...s, ownerId: auth.currentUser.uid, createdAt: Timestamp.now() });
      }

      // Seed mentors
      const mentorsToSeed = [
        { name: "Sarah Lim", expertise: ["Regulatory", "Fintech", "Series A"], geography: "Kuala Lumpur", rating: 4.9, ownerId: auth.currentUser.uid },
        { name: "Marcus Chen", expertise: ["Growth", "SaaS", "GTM Strategy"], geography: "Bangkok", rating: 4.7, ownerId: auth.currentUser.uid }
      ];
      for (const m of mentorsToSeed) {
        await addDoc(collection(db, 'mentors'), { ...m, ownerId: auth.currentUser.uid });
      }

      fetchData();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEntitySuccess = () => {
    fetchData();
  };

  const handleMatch = async (startupId: string) => {
    if (!startupId) return;
    const startup = startups.find(s => s.id === startupId);
    if (!startup) return;

    setIsMatching(true);
    setMatchSuggestions([]);
    
    try {
      const response = await fetch('/api/match/mentors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ startup, mentors })
      });
      const data = await response.json();
      setMatchSuggestions(data);
    } catch (err) {
      console.error("Matching failed:", err);
    } finally {
      setIsMatching(false);
    }
  };

  const initializeLinkage = async (suggestion: any, startupId: string) => {
    if (!auth.currentUser) return;
    try {
      const startup = startups.find(s => s.id === startupId);
      const mentor = mentors.find(m => m.name === suggestion.name);
      
      await addDoc(collection(db, 'relationships'), {
        startupId,
        mentorId: mentor?.id || 'manual-match',
        status: 'pending',
        matchScore: suggestion.score,
        type: 'startup_mentor',
        tags: [suggestion.reason.split(' ')[0] || 'AI_MATCH'],
        ownerId: auth.currentUser.uid,
        createdAt: Timestamp.now()
      });
      
      setMatchSuggestions(prev => prev.filter(s => s.name !== suggestion.name));
      fetchData();
    } catch (err) {
      console.error("Initialization failed:", err);
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Loading EcosystemOS</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-full flex bg-slate-50 font-sans overflow-hidden">
        <div className="flex-1 flex flex-col justify-center px-12 md:px-24 bg-white relative z-10">
           <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-md w-full"
           >
            <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center mb-10 shadow-2xl shadow-slate-900/20">
              <div className="w-6 h-6 bg-blue-500 rounded flex items-center justify-center font-bold text-white text-xs">OS</div>
            </div>
            <h1 className="text-4xl font-bold text-slate-900 mb-6 tracking-tight leading-tight uppercase">
              Ecosystem <span className="text-blue-600 italic">Core</span> Control.
            </h1>
            <p className="text-slate-500 mb-12 text-lg leading-relaxed font-medium">
              Intelligence engine for orchestrating regional innovation ecosystems. Match startups, mentors, and investors with total oversight.
            </p>
            <div className="space-y-4">
              <button 
                onClick={signIn}
                className="w-full flex items-center justify-center gap-4 bg-slate-900 text-white py-4 px-6 rounded-2xl font-bold hover:bg-slate-800 transition-all active:scale-[0.98] shadow-2xl shadow-slate-900/10 text-sm uppercase tracking-widest"
              >
                <img src="https://www.google.com/favicon.ico" className="w-5 h-5 rounded-full invert grayscale" />
                Initialize Access
              </button>
              <div className="flex items-center gap-4 pt-4">
                <div className="h-px bg-slate-100 flex-1"></div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">System Security Enabled</span>
                <div className="h-px bg-slate-100 flex-1"></div>
              </div>
            </div>
          </motion.div>
        </div>
        <div className="hidden lg:block flex-1 relative bg-slate-900 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(59,130,246,0.15),transparent)]"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] h-[140%] bg-[url('https://images.unsplash.com/photo-1454165833767-027508496b60?q=80&w=2070')] bg-cover opacity-10 grayscale mix-blend-screen"></div>
          <div className="absolute bottom-12 left-12">
            <div className="flex items-center gap-3">
               <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
               <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">AI Node: SG-KUL-02 Active</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex h-screen overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} user={user} relationships={relationships} />
      
      <main className="flex-grow flex flex-col overflow-hidden ml-64">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 flex-shrink-0">
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-semibold text-slate-900 tracking-tight">Intelligence Hub</h1>
            <div className="h-4 w-px bg-slate-200"></div>
            <div className="relative group">
              <select 
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="text-[10px] text-slate-500 font-bold uppercase tracking-widest bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100 outline-none hover:border-blue-200 cursor-pointer appearance-none pr-8 transition-all"
              >
                {[
                  'SE Asia / Kuala Lumpur',
                  'East Africa / Nairobi',
                  'Europe / Berlin',
                  'North America / Silicon Valley',
                  'LATAM / Mexico City',
                  'Middle East / Dubai'
                ].map(r => <option key={r} value={r}>{r}</option>)}
              </select>
              <div className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <ChevronRight className="w-3 h-3 rotate-90" />
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Search matches..." 
                className="w-64 bg-slate-100 border-none rounded-full px-10 py-1.5 text-xs focus:ring-2 focus:ring-blue-500 transition-all text-slate-600 outline-none"
              />
            </div>
            {(activeTab === 'startups' || activeTab === 'mentors') && (
              <button 
                onClick={() => {
                  setModalType(activeTab === 'startups' ? 'startup' : 'mentor');
                  setIsModalOpen(true);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-1.5 rounded-full text-xs font-semibold shadow-sm transition-all shadow-blue-600/20 flex items-center gap-2"
              >
                <Plus className="w-3.5 h-3.5" />
                Add {activeTab.slice(0, -1)}
              </button>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-12 gap-6"
              >
                <section className="col-span-12 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                  <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                    <h2 className="text-xs font-bold text-slate-800 uppercase tracking-tight">Priority Ecosystem Insights</h2>
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-[10px] font-bold uppercase">AI Engine Active</span>
                  </div>
                  <div className="p-6 grid grid-cols-3 gap-6 border-b border-slate-50">
                    <MetricCard label="Startups Funnel" value={startups.length} trend="+12.5%" />
                    <MetricCard label="Active Links" value={relationships.length} variant="success" />
                    <MetricCard label="Reuse Rate" value="42%" variant="brand" />
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50/50 text-slate-500 text-[10px] uppercase font-semibold">
                        <tr>
                          <th className="px-6 py-3">Rank</th>
                          <th className="px-6 py-3">Entity Pair</th>
                          <th className="px-6 py-3">Focus Area</th>
                          <th className="px-6 py-3">Fit Score</th>
                          <th className="px-6 py-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-sm">
                        {relationships.slice(0, 4).map((rel, idx) => (
                          <tr key={rel.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-3 font-mono text-slate-400">0{idx + 1}</td>
                            <td className="px-6 py-3">
                              <div className="font-semibold text-slate-800 capitalize">{rel.type.replace('_', ' ↔ ')}</div>
                            </td>
                            <td className="px-6 py-3">
                              <div className="flex flex-wrap gap-1">
                                {rel.tags?.slice(0, 2).map((t, i) => (
                                  <span key={i} className="px-2 py-0.5 border border-slate-200 rounded text-[10px] text-slate-600">{t}</span>
                                ))}
                              </div>
                            </td>
                            <td className="px-6 py-3 font-bold text-emerald-600">{rel.matchScore}/100</td>
                            <td className="px-6 py-3 text-right">
                              <button className="text-blue-600 hover:underline font-semibold text-xs">Initialize</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {relationships.length === 0 && (
                      <div className="py-12 flex flex-col items-center text-center">
                        <AlertCircle className="w-10 h-10 text-slate-300 mb-3" />
                        <p className="text-slate-500 text-sm font-medium">No smart matches available.</p>
                        <button 
                          onClick={seedData}
                          className="mt-4 text-xs font-bold text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-full border border-blue-100 transition-all"
                        >
                          Seed Engine Data
                        </button>
                      </div>
                    )}
                  </div>
                </section>

                <section className="col-span-12 lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xs font-bold text-slate-800 uppercase tracking-tight">Verification Assistant</h2>
                    <span className="text-xs text-slate-500 font-bold">{startups.filter(s => !s.isVerified).length} Alerts</span>
                  </div>
                  <div className="space-y-4">
                    {startups.filter(s => !s.isVerified).slice(0, 3).map((s) => (
                      <div key={s.id} className="flex items-start gap-4 p-3 bg-amber-50 border border-amber-100 rounded-lg">
                        <div className="w-6 h-6 bg-amber-200 rounded-full flex-shrink-0 flex items-center justify-center text-amber-700 text-xs font-bold font-mono">!</div>
                        <div className="flex-grow min-w-0">
                          <div className="text-xs font-bold text-amber-900 truncate">{s.name} (Registration)</div>
                          <p className="text-[11px] text-amber-800 mt-0.5">Missing info. Trust Score: <span className="font-bold">{s.trustScore}%</span>.</p>
                        </div>
                        <button onClick={() => setActiveTab('verification')} className="text-[10px] font-bold text-amber-700 hover:underline flex-shrink-0 uppercase">Resolve</button>
                      </div>
                    ))}
                    {startups.filter(s => !s.isVerified).length === 0 && (
                      <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 text-center text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                        Queue Cleared
                      </div>
                    )}
                  </div>
                </section>

                <section className="col-span-12 lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-sm p-6 overflow-hidden flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xs font-bold text-slate-800 uppercase tracking-tight">Ecosystem Intelligence</h2>
                  </div>
                  <div className="bg-slate-900 text-white p-6 rounded-xl flex-1 relative overflow-hidden group">
                     <div className="relative z-10">
                        <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest mb-1">AI INSIGHT OF THE DAY</p>
                        <h4 className="text-lg font-bold leading-snug">Regulatory expertise is weighting <span className="text-emerald-400">24% higher</span> for fintech seed success this month.</h4>
                        <div className="mt-8 flex gap-2">
                           <span className="px-2 py-1 bg-white/10 rounded text-[9px] font-bold uppercase tracking-wider">#bnm-regulation</span>
                           <span className="px-2 py-1 bg-white/10 rounded text-[9px] font-bold uppercase tracking-wider">#fintech-shift</span>
                        </div>
                     </div>
                     <TrendingUp className="absolute bottom-0 right-0 w-32 h-32 text-white/5 -mb-8 -mr-8 group-hover:scale-110 transition-transform" />
                  </div>
                </section>
              </motion.div>
            )}

            {activeTab === 'startups' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-slate-50/50 text-slate-500 text-[10px] uppercase font-semibold">
                    <tr>
                      <th className="px-6 py-4">Startup Name</th>
                      <th className="px-6 py-4">Vertical</th>
                      <th className="px-6 py-4">Growth Phase</th>
                      <th className="px-6 py-4 text-right">Operation</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {startups.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50/50 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center font-bold text-slate-600 text-xs shadow-sm">
                              {s.name.charAt(0)}
                            </div>
                            <span className="font-semibold text-slate-800">{s.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-xs font-medium text-slate-500">{s.industry}</td>
                        <td className="px-6 py-4">
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-100 text-slate-600 rounded uppercase border border-slate-200/50">
                            {s.stage}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="text-blue-600 hover:underline font-bold text-[11px] uppercase tracking-tighter">View Deep Dive</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </motion.div>
            )}

            {activeTab === 'mentors' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {mentors.map((m) => (
                  <div key={m.id} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all group">
                     <div className="flex justify-between items-start mb-4">
                      <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-sm shadow-sm">
                        {m.name.charAt(0)}
                      </div>
                      <div className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md text-[10px] font-bold">
                        <Star className="w-3 h-3 fill-current" />
                        {m.rating || 'NEW'}
                      </div>
                    </div>
                    <h3 className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors uppercase tracking-tight text-sm">{m.name}</h3>
                    <p className="text-[10px] text-slate-400 mt-1 font-mono uppercase">
                      {m.geography}
                    </p>
                    <div className="mt-4 flex flex-wrap gap-1">
                      {m.expertise.map((exp, i) => (
                        <span key={i} className="text-[9px] font-bold px-1.5 py-0.5 bg-slate-50 text-slate-600 rounded border border-slate-100">
                          #{exp.toLowerCase()}
                        </span>
                      ))}
                    </div>
                    <button className="w-full mt-6 py-2 border border-slate-100 text-slate-500 text-[10px] font-bold rounded-lg hover:bg-slate-900 hover:text-white transition-all uppercase tracking-widest">
                      Engagement Req
                    </button>
                  </div>
                ))}
              </motion.div>
            )}

            {activeTab === 'relationships' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                  <div className="max-w-2xl">
                    <h3 className="text-xl font-bold text-slate-900 mb-2 tracking-tight uppercase">Relationship Orchestration</h3>
                    <p className="text-slate-500 text-sm mb-8 leading-relaxed font-medium">
                      Select a startup to run the AI matching engine. The system will analyze focus areas, growth stage, and geographic intent to suggest optimal matches.
                    </p>
                    
                    <div className="flex gap-4">
                      <select 
                        id="startup-selector"
                        className="flex-1 bg-slate-50 border border-slate-200 p-3 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all text-xs font-bold uppercase tracking-wider"
                      >
                        <option value="">Select Startup...</option>
                        {startups.map(s => (
                          <option key={s.id} value={s.id}>{s.name} [{s.industry}]</option>
                        ))}
                      </select>
                      <button 
                        disabled={isMatching}
                        onClick={() => {
                          const val = (document.getElementById('startup-selector') as HTMLSelectElement).value;
                          handleMatch(val);
                        }}
                        className="bg-slate-900 text-white px-8 py-3 rounded-xl text-[10px] font-black hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10 uppercase tracking-widest disabled:opacity-50"
                      >
                        {isMatching ? 'Processing...' : 'Run IA Matcher'}
                      </button>
                    </div>
                  </div>
                </div>

                {matchSuggestions.length > 0 && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                    <div className="bg-blue-600 text-white p-6 rounded-2xl flex items-center justify-between shadow-xl shadow-blue-600/20">
                      <div>
                        <h4 className="font-bold uppercase tracking-widest text-xs flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4" /> AI Matching Complete
                        </h4>
                        <p className="text-[10px] opacity-80 mt-1 font-bold">Top {matchSuggestions.length} candidates identified based on cross-sector data points.</p>
                      </div>
                    </div>
                    
                    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                      <table className="w-full text-left">
                        <thead className="bg-slate-50/50 text-slate-500 text-[10px] uppercase font-semibold">
                          <tr>
                            <th className="px-6 py-4">Rank</th>
                            <th className="px-6 py-4">Mentor Candidate</th>
                            <th className="px-6 py-4">Fit Score</th>
                            <th className="px-6 py-4">AI Reasoning</th>
                            <th className="px-6 py-4 text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {matchSuggestions.map((sug, idx) => (
                            <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                              <td className="px-6 py-4 font-mono text-slate-400 text-xs">0{idx + 1}</td>
                              <td className="px-6 py-4 font-bold text-slate-800 text-sm">{sug.name}</td>
                              <td className="px-6 py-4">
                                <span className="text-emerald-600 font-black text-sm">{sug.score}/100</span>
                              </td>
                              <td className="px-6 py-4 text-xs text-slate-500 font-medium max-w-xs">{sug.reason}</td>
                              <td className="px-6 py-4 text-right">
                                <button 
                                  onClick={() => initializeLinkage(sug, (document.getElementById('startup-selector') as HTMLSelectElement).value)}
                                  className="text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-lg font-black text-[10px] uppercase tracking-tighter border border-transparent hover:border-blue-100 transition-all"
                                >
                                  Initialize
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </motion.div>
                )}

                <section className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                  <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                    <h2 className="text-xs font-bold text-slate-800 uppercase tracking-tight">Active Relationship Log</h2>
                    <span className="text-[10px] text-slate-400 font-mono">TOTAL_RECORDS: {relationships.length}</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50/50 text-slate-500 text-[10px] uppercase font-semibold">
                        <tr>
                          <th className="px-6 py-4">Linkage ID</th>
                          <th className="px-6 py-4">Status</th>
                          <th className="px-6 py-4">Fit Score</th>
                          <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {relationships.map((rel) => (
                          <tr key={rel.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-4">
                              <div className="font-bold text-slate-800 text-xs">LOG-{rel.id.slice(0, 8).toUpperCase()}</div>
                              <div className="text-[9px] text-slate-400 font-bold uppercase mt-0.5 italic">{rel.type.replace('_', ' ↔ ')}</div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-[9px] font-black uppercase tracking-widest border border-blue-100">
                                {rel.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-xs font-black text-emerald-600">{rel.matchScore}%</td>
                            <td className="px-6 py-4 text-right">
                               <button className="text-slate-400 hover:text-slate-900 transition-colors">
                                  <ChevronRight className="w-4 h-4" />
                               </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>
              </motion.div>
            )}

            {activeTab === 'verification' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 max-w-4xl">
                 <div className="bg-slate-900 text-white p-10 rounded-3xl relative overflow-hidden shadow-2xl">
                    <div className="relative z-10">
                      <h3 className="text-xl font-bold flex items-center gap-3">
                         <ShieldCheck className="w-6 h-6 text-blue-400" />
                         Ecosystem Verification Core
                      </h3>
                      <p className="text-slate-400 text-sm mt-3 leading-relaxed">
                        Secure AI-driven verification for ecosystem participants. Validating legal status, funding history, and domain expertise.
                      </p>
                    </div>
                    <div className="absolute top-0 right-0 p-8">
                       <span className="px-3 py-1 bg-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest border border-white/5">v2.4-stable</span>
                    </div>
                 </div>

                 <div className="space-y-4">
                    {startups.filter(s => !s.isVerified).map((s) => (
                       <div key={s.id} className="bg-white p-6 rounded-xl border border-slate-200 flex items-center gap-6 shadow-sm group">
                          <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center font-black text-slate-400 text-xl font-serif">
                             {s.name.charAt(0)}
                          </div>
                          <div className="flex-1">
                             <h4 className="font-bold text-slate-900">{s.name}</h4>
                             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{s.industry} • {s.stage}</p>
                          </div>
                          <div className="px-4 py-2 bg-slate-50 rounded-lg text-center min-w-[80px]">
                             <p className="text-lg font-black text-slate-800 leading-none">{s.trustScore}%</p>
                             <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Trust</p>
                          </div>
                          <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg text-xs font-bold transition-all shadow-lg shadow-blue-600/10">
                             Verify Entity
                          </button>
                       </div>
                    ))}
                 </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <footer className="h-10 bg-slate-100 border-t border-slate-200 px-8 flex items-center justify-between text-[10px] text-slate-500 flex-shrink-0 font-bold uppercase tracking-tight">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span> AI Model: Ecosystem v2.4-Stable</span>
            <span>Uptime: 99.98%</span>
          </div>
          <div className="flex items-center gap-4">
            <span>May 16, 2026</span>
            <span className="text-slate-300 font-light">|</span>
            <span className="tracking-tighter">Admin: Global Oversight</span>
          </div>
        </footer>
      </main>

      <AddEntityModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        type={modalType} 
        onSuccess={handleEntitySuccess}
      />
    </div>
  );
}
