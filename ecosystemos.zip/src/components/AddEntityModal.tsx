import React, { useState } from 'react';
import { Plus, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db, auth, OperationType, handleFirestoreError } from '../lib/firebase';
import { collection, addDoc, Timestamp } from 'firebase/firestore';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'startup' | 'mentor';
  onSuccess: () => void;
}

export default function AddEntityModal({ isOpen, onClose, type, onSuccess }: ModalProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    industry: '',
    stage: 'idea',
    geography: '',
    expertise: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    setLoading(true);

    try {
      const collectionName = type === 'startup' ? 'companies' : 'mentors';
      const data: any = {
        name: formData.name,
        geography: formData.geography,
        ownerId: auth.currentUser.uid,
        createdAt: Timestamp.now(),
      };

      if (type === 'startup') {
        data.industry = formData.industry;
        data.stage = formData.stage;
        data.isVerified = false;
        data.trustScore = Math.floor(Math.random() * 40) + 30; // Initial score
      } else {
        data.expertise = formData.expertise.split(',').map(s => s.trim());
        data.rating = 0;
      }

      await addDoc(collection(db, collectionName), data);
      onSuccess();
      onClose();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, type);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200"
          >
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                New {type === 'startup' ? 'Startup' : 'Mentor'} Entity
              </h3>
              <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <X className="w-4 h-4 text-slate-500" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Name</label>
                <input 
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                  placeholder={type === 'startup' ? "Company Name" : "Mentor Name"}
                />
              </div>

              {type === 'startup' ? (
                <>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Industry Vertical</label>
                    <input 
                      required
                      value={formData.industry}
                      onChange={e => setFormData({...formData, industry: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                      placeholder="e.g. Fintech, AgriTech"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Startup Stage</label>
                    <select 
                      value={formData.stage}
                      onChange={e => setFormData({...formData, stage: e.target.value})}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                    >
                      <option value="idea">IDEATION</option>
                      <option value="MVP">MVP_PILOT</option>
                      <option value="growth">GROWTH</option>
                      <option value="scale">SCALING</option>
                    </select>
                  </div>
                </>
              ) : (
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Expertise Pools</label>
                  <input 
                    required
                    value={formData.expertise}
                    onChange={e => setFormData({...formData, expertise: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                    placeholder="Separate with commas (e.g. Marketing, Legal)"
                  />
                </div>
              )}

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Geography</label>
                <input 
                  required
                  value={formData.geography}
                  onChange={e => setFormData({...formData, geography: e.target.value})}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                  placeholder="e.g. Singapore"
                />
              </div>

              <div className="pt-4">
                <button 
                  disabled={loading}
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/10 disabled:opacity-50 text-xs uppercase"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  Finalize Registration
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
